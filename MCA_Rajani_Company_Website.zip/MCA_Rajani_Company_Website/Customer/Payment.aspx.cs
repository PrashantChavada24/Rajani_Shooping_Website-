﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class Customer_Payment : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
            Response.Redirect("~/Login/Login.aspx");

        if (Request.QueryString["orderId"] == null)
            Response.Redirect("AddToCart.aspx");
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        int orderId = Convert.ToInt32(Request.QueryString["orderId"]);
        decimal amount = Convert.ToDecimal(Session["OrderAmount"]);

        // Generate Unique Transaction ID
        string txnId = "TXN" + DateTime.Now.Ticks;

        // Mask card number
        string maskedCard = "************" + txtCardNumber.Text.Substring(12);

        int paymentId = 0;

        using (SqlConnection con = new SqlConnection(conStr))
        {
            con.Open();

            // INSERT PAYMENT RECORD
            string q = @"
                INSERT INTO Payment (OrderID, PaymentMode, TransactionID, Amount, 
                                     CardOwnerName, MaskedCardNumber, ExpireDate)
                OUTPUT INSERTED.PaymentID
                VALUES (@OID, 'Card', @TXN, @AMT, @NM, @MC, @EXP)";

            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@OID", orderId);
            cmd.Parameters.AddWithValue("@TXN", txnId);
            cmd.Parameters.AddWithValue("@AMT", amount);
            cmd.Parameters.AddWithValue("@NM", txtCardName.Text);
            cmd.Parameters.AddWithValue("@MC", maskedCard);
            cmd.Parameters.AddWithValue("@EXP", txtExpiry.Text);

            paymentId = Convert.ToInt32(cmd.ExecuteScalar());

            // UPDATE ORDER STATUS
            SqlCommand cmdUpdate = new SqlCommand(
                "UPDATE Orders SET PaymentStatus='Paid' WHERE OrderID=@OID", con);

            cmdUpdate.Parameters.AddWithValue("@OID", orderId);
            cmdUpdate.ExecuteNonQuery();
        }

        // Redirect to Success Page
        Response.Redirect("OrderSuccess.aspx?orderId=" + orderId + "&pid=" + paymentId);
    }
}

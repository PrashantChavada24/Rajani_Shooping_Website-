﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Customer_AddToCart : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("~/Login/Login.aspx");
            return;
        }

        if (!IsPostBack)
            BindCart();
    }

    // =============================================================
    // BIND CART ITEMS
    // =============================================================
    void BindCart()
    {
        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
            SELECT c.CartID, p.ProductName, p.Image, c.Price, c.Quantity
            FROM Cart c
            INNER JOIN Products p ON c.ProductID = p.ProductID
            WHERE c.UserID = @U";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@U", userId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();

            // ------------------------------
            // CALCULATE SUBTOTAL
            // ------------------------------
            decimal subTotal = 0;

            if (dt.Rows.Count > 0)
            {
                subTotal = dt.AsEnumerable()
                    .Sum(r => Convert.ToDecimal(r["Price"]) * Convert.ToInt32(r["Quantity"]));
            }
            // ------------------------------
            // CALCULATE SHIPPING CHARGE
            // ------------------------------
            decimal shipping = 0;

            if (subTotal > 0 && subTotal < 500)
                shipping = 50;    // Change if needed
            else
                shipping = 0;     // Free shipping above 500

            // Save shipping amount for next page
            Session["Shipping"] = shipping;

            // ------------------------------
            // FINAL TOTAL = SUBTOTAL + SHIPPING
            // ------------------------------
            decimal finalAmount = subTotal + shipping;

            // Save for order confirm page & invoice
            Session["FinalAmount"] = finalAmount;

            // ------------------------------
            // DISPLAY ON CART PAGE
            // ------------------------------
            if (lblShipping != null)
                lblShipping.Text = shipping.ToString("0.00");

            if (lblFinalTotal != null)
                lblFinalTotal.Text = finalAmount.ToString("0.00");
        }
    }

    // =============================================================
    // HANDLE ROW COMMANDS (REMOVE / EDIT / UPDATE)
    // =============================================================
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int cartID = Convert.ToInt32(e.CommandArgument);

        // ============================
        // REMOVE ITEM
        // ============================
        if (e.CommandName == "RemoveItem")
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Cart WHERE CartID=@ID", con);
                cmd.Parameters.AddWithValue("@ID", cartID);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            BindCart();
            return;
        }

        // ============================
        // INCREASE QTY
        // ============================
        if (e.CommandName == "IncreaseQty")
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(@"
                    UPDATE Cart SET Quantity = 
                        CASE 
                            WHEN Quantity < 5 THEN Quantity + 1 
                            ELSE 5 
                        END
                    WHERE CartID = @ID", con);

                cmd.Parameters.AddWithValue("@ID", cartID);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            BindCart();
            return;
        }

        // ============================
        // DECREASE QTY
        // ============================
        if (e.CommandName == "DecreaseQty")
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(@"
                    UPDATE Cart SET Quantity = 
                        CASE 
                            WHEN Quantity > 1 THEN Quantity - 1 
                            ELSE 1
                        END
                    WHERE CartID = @ID", con);

                cmd.Parameters.AddWithValue("@ID", cartID);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            BindCart();
            return;
        }
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
        Response.Redirect("Products.aspx");
    }

    protected void btnOrder_Click(object sender, EventArgs e)
    {
        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Cart WHERE UserID=@U", con);
            cmd.Parameters.AddWithValue("@U", userId);

            con.Open();
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count == 0)
            {
                // Show alert
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "cartEmpty", "alert('Your cart is empty! Add items first.');", true);
                return;
            }
        }

        // If cart has items → Redirect
        Response.Redirect("OrderConfirm.aspx");
    }
}
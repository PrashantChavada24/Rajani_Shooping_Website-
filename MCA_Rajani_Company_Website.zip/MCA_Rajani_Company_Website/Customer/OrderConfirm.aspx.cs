﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Customer_OrderConfirm : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("~/Login/Login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            LoadCart();
            LoadUserAddress();
        }
    }

    // ----------------------------------------------------------
    // LOAD USER ADDRESS
    // ----------------------------------------------------------
    void LoadUserAddress()
    {
        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            string q = "SELECT FullName, Mobile, Address FROM Users WHERE UserID=@U";

            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@U", userId);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                txtFullName.Text = dr["FullName"].ToString();
                txtPhone.Text = dr["Mobile"].ToString();
                txtAddressLine.Text = dr["Address"].ToString();
            }

            dr.Close();
        }
    }

    // ----------------------------------------------------------
    // LOAD CART
    // ----------------------------------------------------------
    void LoadCart()
    {
        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"SELECT c.ProductID, p.ProductName, p.Image, 
                                    c.Quantity, c.Price
                             FROM Cart c
                             INNER JOIN Products p ON c.ProductID = p.ProductID
                             WHERE c.UserID = @U";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@U", userId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();

            decimal total = 0;
            foreach (DataRow row in dt.Rows)
                total += Convert.ToDecimal(row["Price"]) * Convert.ToInt32(row["Quantity"]);

            lblTotal.Text = total.ToString();

            Session["OrderAmount"] = total;
        }
    }

    // ----------------------------------------------------------
    // GENERATE INVOICE NUMBER
    // ----------------------------------------------------------
    int GenerateInvoiceNo()
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(
                "SELECT ISNULL(MAX(InvoiceNo), 9999) + 1 FROM Orders", con);
            return Convert.ToInt32(cmd.ExecuteScalar());
        }
    }

    // ----------------------------------------------------------
    // CONFIRM ORDER
    // ----------------------------------------------------------
    protected void btnConfirmOrder_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid) return;

        int userId = Convert.ToInt32(Session["UserID"]);
        decimal subtotal = Convert.ToDecimal(lblTotal.Text);
        decimal shippingCharge = 60; // Fixed shipping charge
        decimal finalAmount = subtotal + shippingCharge;
        string payment = rblPayment.SelectedValue;


        string shippingAddress =
            txtBuildingNo.Text + ", " +
            txtAddressLine.Text + ", " +
            txtCity.Text + " - " + txtPincode.Text +
            ", Mobile: " + txtPhone.Text;

        Session["SubTotal"] = subtotal;
        Session["Shipping"] = shippingCharge;
        Session["FinalAmount"] = finalAmount;
        int orderId = 0;

        using (SqlConnection con = new SqlConnection(conStr))
        {
            con.Open();

            // ------------------ INSERT ORDER MASTER ----------------------
            int invoiceNo = GenerateInvoiceNo();

            SqlCommand cmdOrder = new SqlCommand(@"
                INSERT INTO Orders 
                (InvoiceNo, UserID, OrderTotal, ShippingCharge, FinalAmount, PaymentMethod, ShippingAddress, OrderDate)
                OUTPUT INSERTED.OrderID
                VALUES 
                (@INV, @U, @T, @SC, @FA, @PM, @SA, GETDATE())", con);

            cmdOrder.Parameters.AddWithValue("@INV", invoiceNo);
            cmdOrder.Parameters.AddWithValue("@U", userId);
            cmdOrder.Parameters.AddWithValue("@T", subtotal);
            cmdOrder.Parameters.AddWithValue("@SC", shippingCharge);
            cmdOrder.Parameters.AddWithValue("@FA", finalAmount);
            cmdOrder.Parameters.AddWithValue("@PM", payment);
            cmdOrder.Parameters.AddWithValue("@SA", shippingAddress);

            

            orderId = Convert.ToInt32(cmdOrder.ExecuteScalar());

            // ------------------ FETCH CART DATA FIRST ----------------------
            SqlCommand cmdCart = new SqlCommand(@"
                SELECT c.ProductID, c.Quantity, c.Price, p.Weight
                FROM Cart c
                INNER JOIN Products p ON c.ProductID = p.ProductID
                WHERE c.UserID = @U", con);

            cmdCart.Parameters.AddWithValue("@U", userId);

            SqlDataAdapter da = new SqlDataAdapter(cmdCart);
            DataTable cartDT = new DataTable();
            da.Fill(cartDT);

            // ------------------ INSERT ORDER DETAILS ----------------------
            foreach (DataRow row in cartDT.Rows)
            {
              
                SqlCommand cmdDetails = new SqlCommand(@"
                INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price, Weight)
                VALUES (@O, @P, @Q, @PR, @W)", con);

                cmdDetails.Parameters.AddWithValue("@O", orderId);
                cmdDetails.Parameters.AddWithValue("@P", row["ProductID"]);
                cmdDetails.Parameters.AddWithValue("@Q", row["Quantity"]);
                cmdDetails.Parameters.AddWithValue("@PR", row["Price"]);
                cmdDetails.Parameters.AddWithValue("@W", row["Weight"]);

                cmdDetails.ExecuteNonQuery();
            }

            // ------------------ UPDATE PRODUCT STOCK ----------------------
            foreach (DataRow row in cartDT.Rows)
            {
                SqlCommand cmdStock = new SqlCommand(@"
                    UPDATE Products 
                    SET Quantity = Quantity - @Q
                    WHERE ProductID = @P", con);

                cmdStock.Parameters.AddWithValue("@Q", row["Quantity"]);
                cmdStock.Parameters.AddWithValue("@P", row["ProductID"]);

                cmdStock.ExecuteNonQuery();
            }

            // ------------------ CLEAR CART ----------------------
            SqlCommand cmdClear = new SqlCommand("DELETE FROM Cart WHERE UserID=@U", con);
            cmdClear.Parameters.AddWithValue("@U", userId);
            cmdClear.ExecuteNonQuery();
        }

        // ------------------ SAVE FOR INVOICE ----------------------
        Session["CustName"] = txtFullName.Text;
        Session["CustPhone"] = txtPhone.Text;
        Session["CustAddress"] =
            txtBuildingNo.Text + ", " +
            txtAddressLine.Text + ", " +
            txtCity.Text + " - " + txtPincode.Text;

        // ------------------ REDIRECT ----------------------
        if (payment == "Card")
            Response.Redirect("Payment.aspx?orderId=" + orderId);
        else
            Response.Redirect("OrderSuccess.aspx?orderId=" + orderId);
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddToCart.aspx");
    }
}
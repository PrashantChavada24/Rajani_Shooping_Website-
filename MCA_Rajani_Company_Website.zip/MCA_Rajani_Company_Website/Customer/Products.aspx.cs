﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Customer_Products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("~/Login/Login.aspx");   // redirect to login page
            return;
        }

        if (!IsPostBack)
            
            LoadAllProducts();

    }
    // LOAD ALL PRODUCTS
    void LoadAllProducts()
    {
        string query = "SELECT * FROM Products";

        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString))
        using (SqlCommand cmd = new SqlCommand(query, con))
        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
        {
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataList1.DataSource = dt;
            DataList1.DataBind();
        }
    }
     void LoadProducts(int categoryId)
    {
        string query = "SELECT * FROM Products WHERE CategoryID=@C";

        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString))
        using (SqlCommand cmd = new SqlCommand(query, con))
        {
            cmd.Parameters.AddWithValue("@C", categoryId);

            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);

                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
        }
    }
    protected void Category_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        int categoryId = int.Parse(btn.CommandArgument);
        LoadProducts(categoryId);
    }
  protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
{
    if (e.CommandName == "BuyProduct")
    {
        int productId = Convert.ToInt32(e.CommandArgument);

        // Get Quantity
        DropDownList ddl = (DropDownList)e.Item.FindControl("ddlQty");
        int qty = Convert.ToInt32(ddl.SelectedValue);

        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString))
        {
            con.Open();

            // Get Product Price & Stock
            SqlCommand productCmd = new SqlCommand(
                "SELECT Price, Quantity FROM Products WHERE ProductID=@P", con);
            productCmd.Parameters.AddWithValue("@P", productId);

            SqlDataReader dr = productCmd.ExecuteReader();
            decimal price = 0;
            int stockQty = 0;

            if (dr.Read())
            {
                price = Convert.ToDecimal(dr["Price"]);
                stockQty = Convert.ToInt32(dr["Quantity"]);
            }
            dr.Close();

            // 1️⃣ If stock is ZERO → stop & show message
            if (stockQty == 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "StockZero",
                    "alert('This product is OUT OF STOCK!');",
                    true);
                return;
            }

            // 2️⃣ If user selected qty > available stock → stop & show message
            if (qty > stockQty)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                "InsufficientStock",
                "alert('Only " + stockQty + " quantity available!');",
                true);

                return;
            }

            // -------------------------
            // 3️⃣ Add / Update Cart Logic
            // -------------------------

            string checkQuery = "SELECT Quantity FROM Cart WHERE UserID=@U AND ProductID=@P";
            SqlCommand checkCmd = new SqlCommand(checkQuery, con);
            checkCmd.Parameters.AddWithValue("@U", userId);
            checkCmd.Parameters.AddWithValue("@P", productId);

            object result = checkCmd.ExecuteScalar();

            if (result != null)
            {
                int newQty = Convert.ToInt32(result) + qty;

                // Check if new quantity exceeds stock
                if (newQty > stockQty)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(),
                        "ExceedsStock",
                        "alert('Only " + stockQty + " quantity available!');",
                        true);
                    return;
                }

                string updateQuery = "UPDATE Cart SET Quantity=@Q WHERE UserID=@U AND ProductID=@P";
                SqlCommand updateCmd = new SqlCommand(updateQuery, con);
                updateCmd.Parameters.AddWithValue("@Q", newQty);
                updateCmd.Parameters.AddWithValue("@U", userId);
                updateCmd.Parameters.AddWithValue("@P", productId);
                updateCmd.ExecuteNonQuery();
            }
            else
            {
                string insertQuery = "INSERT INTO Cart(UserID, ProductID, Quantity, Price) VALUES (@U, @P, @Q, @Price)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, con);

                insertCmd.Parameters.AddWithValue("@U", userId);
                insertCmd.Parameters.AddWithValue("@P", productId);
                insertCmd.Parameters.AddWithValue("@Q", qty);
                insertCmd.Parameters.AddWithValue("@Price", price);

                insertCmd.ExecuteNonQuery();
            }
        }

        ScriptManager.RegisterStartupScript(this, this.GetType(),
        "AddedToCart",
        "alert('Item added to cart successfully!');",
        true);
    }
}
  protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
  {
      if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
      {
          Label lblStock = (Label)e.Item.FindControl("lblStock");
          Button btnBuy = (Button)e.Item.FindControl("btnBuy");
          DropDownList ddlQty = (DropDownList)e.Item.FindControl("ddlQty");
          Label lblOut = (Label)e.Item.FindControl("lblOut");

          int stock = Convert.ToInt32(lblStock.Text);

          if (stock == 0)
          {
              btnBuy.Enabled = false;
              ddlQty.Enabled = false;
              lblOut.Visible = true;
          }
      }
  }
    protected void btnall_Click(object sender, EventArgs e)
    {
        LoadAllProducts();
    }
}
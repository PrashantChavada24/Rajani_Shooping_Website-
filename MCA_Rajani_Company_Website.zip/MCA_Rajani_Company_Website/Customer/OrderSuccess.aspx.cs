﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class Customer_OrderSuccess : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["orderId"] == null)
            {
                Response.Redirect("Home.aspx");
                return;
            }

            int orderId = Convert.ToInt32(Request.QueryString["orderId"]);
            LoadOrderMaster(orderId);
            LoadOrderItems(orderId);
        }
    }

    // ===============================================
    // LOAD ORDER HEADER
    // ===============================================
    void LoadOrderMaster(int orderId)
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
            SELECT 
                o.OrderID, 
                o.InvoiceNo, 
                o.OrderTotal, 
                o.ShippingCharge,
                o.FinalAmount,
                o.PaymentMethod,
                o.OrderDate, 
                o.ShippingAddress,
                ISNULL(p.PaymentID, '-') AS PaymentID
            FROM Orders o
            LEFT JOIN Payment p ON o.OrderID = p.OrderID
            WHERE o.OrderID = @OID";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@OID", orderId);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                lblInvoice.Text = dr["InvoiceNo"].ToString();
                lblOrderID.Text = dr["OrderID"].ToString();
                lblPaymentID.Text = dr["PaymentID"].ToString();

                lblDate.Text = Convert.ToDateTime(dr["OrderDate"]).ToString("dd-MM-yyyy");
                lblAddress.Text = dr["ShippingAddress"].ToString();

                // Load Customer Name & Mobile from Session
                lblCustName.Text = Session["CustName"].ToString();
                lblCustMobile.Text = Session["CustPhone"].ToString();

                // VALUES FROM DATABASE
                decimal subTotal = Convert.ToDecimal(dr["OrderTotal"]);
                decimal shipping = Convert.ToDecimal(dr["ShippingCharge"]);
                decimal finalAmount = Convert.ToDecimal(dr["FinalAmount"]);

                // GST CALCULATION
                decimal cgst = subTotal * 0.09m;
                decimal sgst = subTotal * 0.09m;
                decimal gstTotal = subTotal + cgst + sgst;
                decimal grandTotal=subTotal+cgst+sgst+shipping;

                // ASSIGN DISPLAY VALUES
                lblSubTotal.Text = subTotal.ToString("0.00");
                lblCGST.Text = cgst.ToString("0.00");
                lblSGST.Text = sgst.ToString("0.00");

               
                // SHIPPING
                lblShipping.Text = shipping.ToString("0.00");

                //subtotal+gsttotal
                lblFinal.Text = gstTotal.ToString("0.00");

                // Grand Total shown as Final Amount
                lblGrandTotal.Text = grandTotal.ToString("0.00");
            }

            dr.Close();
        }
    }

    // ===============================================
    // LOAD ORDER ITEMS (WEIGHT AS NVARCHAR)
    // ===============================================
    void LoadOrderItems(int orderId)
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
                SELECT p.ProductName, d.Quantity, d.Price, p.Weight
                FROM OrderDetails d
                INNER JOIN Products p ON d.ProductID = p.ProductID
                WHERE d.OrderID = @OID";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@OID", orderId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();

            ViewState["OrderItems"] = dt;   // For PDF
        }
    }

    // ===============================================
    // PDF DOWNLOAD
    // ===============================================
    protected void btnPDF_Click(object sender, EventArgs e)
    {
        int orderId = Convert.ToInt32(Request.QueryString["orderId"]);

        Document pdfDoc = new Document(PageSize.A4, 25f, 25f, 30f, 30f);
        MemoryStream ms = new MemoryStream();
        PdfWriter writer = PdfWriter.GetInstance(pdfDoc, ms);

        pdfDoc.Open();

        // ---------------- HEADER ----------------
        PdfPTable header = new PdfPTable(2);
        header.WidthPercentage = 100;

        PdfPCell companyCell = new PdfPCell();
        companyCell.Border = Rectangle.NO_BORDER;
        companyCell.AddElement(new Paragraph("RAJANI TRADING COMPANY", new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD)));
        companyCell.AddElement(new Paragraph("Jetpur - Junagadh Hwy, Navi Sankali, Gujarat 360360"));
        companyCell.AddElement(new Paragraph("Email: support@rajani.com"));
        companyCell.AddElement(new Paragraph("Contact: +91 98765 43210"));

        header.AddCell(companyCell);
        header.AddCell(new PdfPCell() { Border = Rectangle.NO_BORDER });

        pdfDoc.Add(header);
        pdfDoc.Add(new Paragraph("\n--------------------------------------------------------------------------------------------------------------------\n"));

        // ---------------- TITLE ----------------
        Paragraph title = new Paragraph("INVOICE", new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD));
        title.Alignment = Element.ALIGN_CENTER;
        pdfDoc.Add(title);
        pdfDoc.Add(new Paragraph("\n"));

        // ---------------- ORDER INFO ----------------
        PdfPTable info = new PdfPTable(2);
        info.WidthPercentage = 100;

        PdfPCell left = new PdfPCell();
        left.Border = Rectangle.NO_BORDER;
        left.AddElement(new Paragraph("Invoice No: " + lblInvoice.Text));
        left.AddElement(new Paragraph("Order ID: " + lblOrderID.Text));
        left.AddElement(new Paragraph("Order Date: " + lblDate.Text));
        left.AddElement(new Paragraph("Payment ID: " + lblPaymentID.Text));

        PdfPCell right = new PdfPCell();
        right.Border = Rectangle.NO_BORDER;
        right.AddElement(new Paragraph("Customer Name: " + lblCustName.Text));
        right.AddElement(new Paragraph("Mobile: " + lblCustMobile.Text));
        right.AddElement(new Paragraph("Address: " + lblAddress.Text));

        info.AddCell(left);
        info.AddCell(right);
        pdfDoc.Add(info);
        pdfDoc.Add(new Paragraph("\n"));

        // ---------------- PRODUCT TABLE ----------------
        PdfPTable table = new PdfPTable(5);
        table.WidthPercentage = 100;
        table.SetWidths(new float[] { 35f, 15f, 15f, 15f, 20f });

        table.AddCell("Product");
        table.AddCell("Qty");
        table.AddCell("Weight");
        table.AddCell("Price");
        table.AddCell("Total");

        foreach (GridViewRow row in GridView1.Rows)
        {
            string product = row.Cells[0].Text;
            int qty = int.Parse(row.Cells[1].Text);

            string weight = row.Cells[2].Text;   // EXACT NVARCHAR VALUE
            string priceStr = row.Cells[3].Text;

            decimal price = 0;
            decimal.TryParse(priceStr, out price);

            decimal total = qty * price;

            table.AddCell(product);
            table.AddCell(qty.ToString());
            table.AddCell(weight);                      // NO CONVERSION
            table.AddCell("₹ " + price.ToString("0.00"));
            table.AddCell("₹ " + total.ToString("0.00"));
        }

        pdfDoc.Add(table);
        pdfDoc.Add(new Paragraph("\n"));

        // ---------------- GST SUMMARY ----------------
        PdfPTable gst = new PdfPTable(2);
        gst.WidthPercentage = 50;
        gst.HorizontalAlignment = Element.ALIGN_RIGHT;

        gst.AddCell("Sub Total");
        gst.AddCell("₹ " + lblSubTotal.Text);

        gst.AddCell("Shipping Charge");
        gst.AddCell("₹ " + lblShipping.Text);

        gst.AddCell("CGST 9%");
        gst.AddCell("₹ " + lblCGST.Text);

        gst.AddCell("SGST 9%");
        gst.AddCell("₹ " + lblSGST.Text);

        gst.AddCell("Grand Total");
        gst.AddCell("₹ " + lblGrandTotal.Text);

        pdfDoc.Add(gst);

        // ---------------- FOOTER ----------------
        Paragraph footer = new Paragraph(
            "\nThank you for shopping with Rajani Trading Company!\nFor support: support@rajani.com\nWe appreciate your business.",
            new Font(Font.FontFamily.HELVETICA, 11, Font.ITALIC, BaseColor.DARK_GRAY)
        );
        footer.Alignment = Element.ALIGN_CENTER;
        pdfDoc.Add(footer);

        pdfDoc.Close();

        // SEND PDF
        byte[] bytes = ms.ToArray();
        ms.Close();

        Response.ContentType = "application/pdf";
        Response.AddHeader("Content-Disposition", "attachment; filename=Invoice_" + orderId + ".pdf");
        Response.BinaryWrite(bytes);
        Response.End();
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
        Response.Redirect("Products.aspx");
    }
}
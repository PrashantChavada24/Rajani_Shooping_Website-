﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Customer_UserProfile : System.Web.UI.Page
{
        string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("~/Login/Login.aspx");
            return;
        }

        if (!IsPostBack)
            LoadUserData();
    }

    // LOAD USER DETAILS
    void LoadUserData()
    {
        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            string q = "SELECT FullName, Mobile, Email, Address FROM Users WHERE UserID=@U";

            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@U", userId);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                txtFullName.Text = dr["FullName"].ToString();
                txtMobile.Text = dr["Mobile"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtAddress.Text = dr["Address"].ToString();
            }
            dr.Close();
        }
    }

    // UPDATE PROFILE
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid)
            return;

        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            string q = @"UPDATE Users SET 
                        FullName=@N, Mobile=@M, Address=@A 
                        WHERE UserID=@U";

            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@N", txtFullName.Text);
            cmd.Parameters.AddWithValue("@M", txtMobile.Text);
            cmd.Parameters.AddWithValue("@A", txtAddress.Text);
            cmd.Parameters.AddWithValue("@U", userId);

            con.Open();
            cmd.ExecuteNonQuery();
        }

        // UPDATE HEADER NAME
        Session["FullName"] = txtFullName.Text;

        ScriptManager.RegisterStartupScript(
                this,
                this.GetType(),
                "alertRedirect",
                "alert('Profile updated successfully!!'); window.location='/Mca_Rajani_Company_Website/Customer/Home.aspx';",
                true
            );
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Customer_Customer : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string page = System.IO.Path.GetFileName(Request.Url.AbsolutePath);

        // =====================
        // Highlight Main Menu
        // =====================
        if (page == "Home.aspx") lnkHome.Attributes["class"] = "active";
        if (page == "Products.aspx") lnkProducts.Attributes["class"] = "active";
        if (page == "About.aspx") lnkAbout.Attributes["class"] = "active";
        

        // =====================
        // Highlight Customer Menu
        // =====================
        if (page == "Profile.aspx") lnkProfile.Attributes["class"] = "active";
        if (page == "OrderHistory.aspx") lnkOrders.Attributes["class"] = "active";
        if (page == "~/Login/ChangePassword.aspx") lnkChangePassword.Attributes["class"] = "active";

        // =====================
        // Highlight Header Buttons
        // =====================
        if (page == "AddToCart.aspx") lnkCart.Attributes["class"] += " active";
        if (page == "Login.aspx") lnkLogin.Attributes["class"] += " active";

        // =====================
        // Show Welcome + Logout
        // =====================
        if (!IsPostBack)
        {
            if (Session["FullName"] != null)
            {
                lblWelcome.InnerText = "Welcome, " + Session["FullName"].ToString();
                lblWelcome.Style["display"] = "inline-block";

                lnkLogout.Style["display"] = "inline-block";
                lnkLogin.Style["display"] = "none";
            }
            else
            {
                lblWelcome.Style["display"] = "none";
                lnkLogout.Style["display"] = "none";
                lnkLogin.Style["display"] = "inline-block";
            }
            // NEW — Load cart count
            LoadCartCount();
        }
    }
    private void LoadCartCount()
    {
        if (Session["UserID"] != null)
        {
            int userId = Convert.ToInt32(Session["UserID"]);

            string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string query = "SELECT COUNT(*) FROM Cart WHERE UserID=@U"; // COUNT ITEMS

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@U", userId);

                con.Open();
                object result = cmd.ExecuteScalar();
                con.Close();

                int count = (result == DBNull.Value || result == null) ? 0 : Convert.ToInt32(result);

                // Set in header
                lblCartCount.InnerText = count.ToString();
            }
        }
        else
        {
            lblCartCount.InnerText = "0";
        }
    }

}

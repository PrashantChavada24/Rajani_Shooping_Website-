﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Customer_OrderHistory : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Redirect("~/Login/Login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            LoadOrderHistory();
        }
    }

    void LoadOrderHistory()
    {
        int userId = Convert.ToInt32(Session["UserID"]);

        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
                SELECT 
                    o.InvoiceNo,
                    o.OrderID,
                    o.OrderDate,
                    p.ProductName,
                    p.Image,
                    d.Weight,
                    d.Price,
                    d.Quantity,
                    o.OrderTotal, 
                    o.ShippingCharge,
                    o.FinalAmount,
                    ISNULL(o.PaymentStatus, 'Pending') AS PaymentStatus
                FROM Orders o
                INNER JOIN OrderDetails d ON o.OrderID = d.OrderID
                INNER JOIN Products p ON d.ProductID = p.ProductID
                WHERE o.UserID = @U
                ORDER BY o.OrderID DESC";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@U", userId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}
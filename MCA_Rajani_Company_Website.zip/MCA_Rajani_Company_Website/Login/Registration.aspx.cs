﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

public partial class Login_Registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(
        ConfigurationManager.ConnectionStrings["DbConnection"].ToString()
    );

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    // Gender validator
    protected void cvGender_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = rbMale.Checked || rbFemale.Checked;
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        // ASP.NET validators already validate fields
        if (!Page.IsValid)
            return;

        // Check if username already exists
        string checkQuery = "SELECT COUNT(*) FROM Users WHERE Username=@u";
        SqlCommand checkCmd = new SqlCommand(checkQuery, con);
        checkCmd.Parameters.AddWithValue("@u", txtUser.Text);

        con.Open();
        int userCount = Convert.ToInt32(checkCmd.ExecuteScalar());
        con.Close();

        if (userCount > 0)
        {
            lblMessage.Text = "Username already exists! Try another.";
            lblMessage.ForeColor = System.Drawing.Color.Red;
            return;
        }

        // Get selected gender
        string gender = rbMale.Checked ? "Male" : "Female";

        // Insert new user
        string insertQuery = "INSERT INTO Users (FullName, Username, Password, Email, Address, Gender, Mobile) " +
                             "VALUES (@name, @username, @password, @email, @address, @gender, @mobile)";

        SqlCommand cmd = new SqlCommand(insertQuery, con);

        cmd.Parameters.AddWithValue("@name", txtName.Text);
        cmd.Parameters.AddWithValue("@username", txtUser.Text);
        cmd.Parameters.AddWithValue("@password", txtPass.Text);
        cmd.Parameters.AddWithValue("@email", txtEmail.Text);
        cmd.Parameters.AddWithValue("@address", txtAddress.Text);
        cmd.Parameters.AddWithValue("@gender", gender);
        cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);

        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        // Success message
        lblMessage.Text = "Registration successful! Redirecting to login...";
        lblMessage.ForeColor = System.Drawing.Color.Green;

        // Clear fields
        txtName.Text = "";
        txtUser.Text = "";
        txtPass.Text = "";
        txtEmail.Text = "";
        txtAddress.Text = "";
        txtMobile.Text = "";
        rbMale.Checked = false;
        rbFemale.Checked = false;

        // Redirect to login page after 2 sec
        Response.AddHeader("REFRESH", "2;URL=Login.aspx");
    }
}
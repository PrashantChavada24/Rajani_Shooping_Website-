﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class Login_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
          SqlConnection con = new SqlConnection(
            ConfigurationManager.ConnectionStrings["DbConnection"].ToString()
        );

        // 1️⃣ Check Admin Login
        string adminQuery = "SELECT * FROM AdminLogin WHERE Username=@u AND Password=@p";
        SqlCommand cmd1 = new SqlCommand(adminQuery, con);
        cmd1.Parameters.AddWithValue("@u", txtUser.Text);
        cmd1.Parameters.AddWithValue("@p", txtPass.Text);

        con.Open();
        SqlDataReader dr1 = cmd1.ExecuteReader();

        if (dr1.HasRows)
        {
            con.Close();
            Session["admin"] = txtUser.Text;
            Response.Redirect("~/Admin/AdminHome.aspx");  // Admin page
            return;
        }
        con.Close();


        // 2️⃣ Check Customer Login
        string userQuery = "SELECT UserID,FullName FROM Users WHERE Username=@u AND Password=@p";
        SqlCommand cmd2 = new SqlCommand(userQuery, con);
        cmd2.Parameters.AddWithValue("@u", txtUser.Text);
        cmd2.Parameters.AddWithValue("@p", txtPass.Text);

        con.Open();
        SqlDataReader dr2 = cmd2.ExecuteReader();

        if (dr2.Read())   // user found
        {
            // Save session values
            Session["UserID"] = dr2["UserID"];       // <-- REQUIRED FOR CART
            Session["FullName"] = dr2["FullName"].ToString();   // optional

            con.Close();
            Response.Redirect("~/Customer/Home.aspx");
        }
        else
        {
            con.Close();
            lblMessage.Text = "Invalid Username or Password!";
        }
        con.Close();
    
    }
    
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;


public partial class Customer_ChangePassword : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            lblShowOtp.Text = "";
    }

    // Generate 6-digit OTP
    public string GenerateOTP()
    {
        Random rnd = new Random();
        return rnd.Next(100000, 999999).ToString();
    }

    // SEND OTP EMAIL
    public void SendOtpEmail(string email, string otp)
    {
        try
        {
            MailMessage mm = new MailMessage();
            mm.From = new MailAddress("chavdaprashant033@gmail.com");  // CHANGE
            mm.To.Add(email);
            mm.Subject = "Your Password Reset OTP";
            mm.Body = "Your OTP for password reset is: " + otp;
            mm.IsBodyHtml = false;

            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.EnableSsl = true;

            smtp.Credentials = new NetworkCredential("chavdaprashant033@gmail.com", "falh tiup mlex gckp"); // CHANGE

            smtp.Send(mm);

            lblShowOtp.Text = "OTP sent to your email!";
        }
        catch (Exception ex)
        {
            lblShowOtp.Text = "Error sending email: " + ex.Message;
        }
    }

    protected void btnSendOtp_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();

        using (SqlConnection con = new SqlConnection(conStr))
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Email=@E", con);
            cmd.Parameters.AddWithValue("@E", email);

            int exists = Convert.ToInt32(cmd.ExecuteScalar());

            if (exists == 1)
            {
                string otp = GenerateOTP();

                Session["otp"] = otp;
                Session["email"] = email;

                SendOtpEmail(email, otp);

                lblMsg.Text = "<span class='msg-success'>OTP sent to your email!</span>";
                
            }
            else
            {
                lblMsg.Text = "<span class='msg-error'>Email not registered!</span>";
            }
        }
    }

    protected void btnVerifyOtp_Click(object sender, EventArgs e)
    {
        if (Session["otp"] == null)
        {
            lblMsg.Text = "<span class='msg-error'>Please send OTP first!</span>";
            return;
        }

        string enteredOtp = txtOtp.Text.Trim();

        if (enteredOtp == Session["otp"].ToString())
        {
            lblMsg.Text = "<span class='msg-success'>OTP Verified! Enter new password.</span>";

            txtNewPassword.Enabled = true;
            txtConfirmPassword.Enabled = true;
            btnChange.Enabled = true;
        }
        else
        {
            lblMsg.Text = "<span class='msg-error'>Invalid OTP!</span>";
        }
    }

    protected void btnChange_Click(object sender, EventArgs e)
    {
        string newPass = txtNewPassword.Text.Trim();
        string confirmPass = txtConfirmPassword.Text.Trim();

        if (newPass != confirmPass)
        {
            lblMsg.Text = "<span class='msg-error'>Passwords do not match!</span>";
            return;
        }

        string email = Session["email"].ToString();

        if (email == null)
        {
            lblMsg.Text = "<span class='msg-error'>Session expired. Try again.</span>";
            return;
        }

        using (SqlConnection con = new SqlConnection(conStr))
        {
            con.Open();

            SqlCommand cmd = new SqlCommand(
                "UPDATE Users SET Password=@P WHERE Email=@E", con);
            cmd.Parameters.AddWithValue("@P", newPass);
            cmd.Parameters.AddWithValue("@E", email);

            cmd.ExecuteNonQuery();
        }

        ScriptManager.RegisterStartupScript(
            this, this.GetType(), "alert",
            "alert('Password changed successfully!'); window.location='/MCA_Rajani_Company_Website/Login/Login.aspx';",
            true
        );
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_UpdateOrder : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);
    int id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["ID"] == null)
            Response.Redirect("Orders.aspx");

        id = Convert.ToInt32(Request.QueryString["ID"]);

        if (!IsPostBack)
            LoadOrder();
    }

    void LoadOrder()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(
            "SELECT OrderStatus, PaymentStatus FROM Orders WHERE OrderID=@ID", con);
        cmd.Parameters.AddWithValue("@ID", id);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            ddlStatus.SelectedValue = dr["OrderStatus"].ToString();
            ddlPayment.SelectedValue = dr["PaymentStatus"].ToString();
        }
        con.Close();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(
            @"UPDATE Orders SET 
                OrderStatus=@Status,
                PaymentStatus=@Payment
              WHERE OrderID=@ID", con);

        cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedValue);
        cmd.Parameters.AddWithValue("@Payment", ddlPayment.SelectedValue);
        cmd.Parameters.AddWithValue("@ID", id);

        cmd.ExecuteNonQuery();
        con.Close();

        Response.Write("<script>alert('Order Updated Successfully!');window.location='Orders.aspx';</script>");
    }
}
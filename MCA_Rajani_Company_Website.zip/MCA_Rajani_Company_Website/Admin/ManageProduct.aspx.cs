﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_ManageProduct : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCategoryFilter();
            LoadProducts();
        }
    }
    void LoadCategoryFilter()
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            SqlCommand cmd = new SqlCommand("SELECT CategoryID, CategoryName FROM Category", con);

            con.Open();
            ddlCategory.DataSource = cmd.ExecuteReader();
            ddlCategory.DataTextField = "CategoryName";
            ddlCategory.DataValueField = "CategoryID";
            ddlCategory.DataBind();
        }

        ddlCategory.Items.Insert(0, new ListItem("All", "0"));
    }
    void LoadProducts()
    {
        string query = @"
        SELECT p.ProductID, p.ProductName, c.CategoryName,
               p.Weight, p.Price, p.Quantity, p.Image
        FROM Products p
        INNER JOIN Category c ON p.CategoryID = c.CategoryID
        WHERE 1 = 1";

        if (ddlCategory.SelectedValue != "0")
            query += " AND p.CategoryID = @CID";

        using (SqlConnection con = new SqlConnection(conStr))
        using (SqlCommand cmd = new SqlCommand(query, con))
        {
            if (ddlCategory.SelectedValue != "0")
                cmd.Parameters.AddWithValue("@CID", ddlCategory.SelectedValue);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridProducts.DataSource = dt;
            GridProducts.DataBind();
        }
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadProducts();
    }

    protected void GridProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridProducts.PageIndex = e.NewPageIndex;
        LoadProducts();
    }
    protected void GridProducts_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);

        if (e.CommandName == "editrow")
        {
            Response.Redirect("EditProduct.aspx?ID=" + id);
        }

        if (e.CommandName == "deleterow")
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Products WHERE ProductID=@ID", con);
                cmd.Parameters.AddWithValue("@ID", id);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            LoadProducts(); // refresh grid
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_Orders : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadOrders();
        }
    }

    void LoadOrders()
    {
        string status = ddlStatusFilter.SelectedValue;
        string orderStatus = ddlOrderStatus.SelectedValue;
        string paymentMethod = ddlPaymentMethod.SelectedValue;
        string dateFilter = txtOrderDate.Text.Trim();

        string query = @"
            SELECT O.OrderID, O.InvoiceNo, U.FullName,
                   O.OrderTotal, O.ShippingCharge, O.FinalAmount,
                   O.PaymentMethod, O.PaymentStatus, O.OrderStatus, O.OrderDate
            FROM Orders O
            INNER JOIN Users U ON O.UserID = U.UserID
            WHERE 1 = 1";

        if (status != "All")
            query += " AND O.PaymentStatus = @Status";

        // Order Status Filter
        if (orderStatus != "All")
            query += " AND O.OrderStatus = @OrderStatus";

        // Payment Method Filter
        if (paymentMethod != "All")
            query += " AND O.PaymentMethod = @PaymentMethod";

        if (!string.IsNullOrEmpty(dateFilter))
            query += " AND CAST(O.OrderDate AS DATE) = @Date";

        using (SqlCommand cmd = new SqlCommand(query, con))
        {
            if (status != "All") 
                cmd.Parameters.AddWithValue("@Status", status);
            if (orderStatus != "All")
                cmd.Parameters.AddWithValue("@OrderStatus", orderStatus);
            if (paymentMethod != "All")
                cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);

            if (!string.IsNullOrEmpty(dateFilter)) 
                cmd.Parameters.AddWithValue("@Date", dateFilter);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridOrders.DataSource = dt;
            GridOrders.DataBind();
        }
    }

    protected void ddlStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadOrders();
    }
    protected void Filter_Changed(object sender, EventArgs e)
    {
        LoadOrders();
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadOrders();
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlStatusFilter.SelectedValue = "All";
        ddlOrderStatus.SelectedValue = "All";
        ddlPaymentMethod.SelectedValue = "All";
        txtOrderDate.Text = "";
        LoadOrders();
    }

    protected void GridOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridOrders.PageIndex = e.NewPageIndex;
        LoadOrders();
    }

    protected void GridOrders_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int orderId = Convert.ToInt32(e.CommandArgument);

        if (e.CommandName == "vieworder")
            Response.Redirect("ViewOrder.aspx?ID=" + orderId);

        if (e.CommandName == "updateorder")
            Response.Redirect("UpdateOrder.aspx?ID=" + orderId);
    }
}

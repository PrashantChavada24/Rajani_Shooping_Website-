﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_AddProduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCategory();
        }
    }

    void LoadCategory()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT CategoryID, CategoryName FROM Category", con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        ddlCategory.DataSource = dt;
        ddlCategory.DataTextField = "CategoryName";
        ddlCategory.DataValueField = "CategoryID";   // FIXED HERE
        ddlCategory.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
       if (!Page.IsValid)
            return;

        string fileName = "";

        if (FileImage.HasFile)
        {
            string ext = System.IO.Path.GetExtension(FileImage.FileName).ToLower();

            if (ext != ".jpg" && ext != ".png" && ext != ".jpeg")
            {
                lblMsg.Text = "Only JPG, PNG files allowed!";
                lblMsg.CssClass = "text-danger";
                return;
            }

            fileName = System.IO.Path.GetFileName(FileImage.FileName);  // Only name
            FileImage.SaveAs(Server.MapPath("~/ProductImages/" + fileName));
        }

        SqlCommand cmd = new SqlCommand(
                 @"INSERT INTO Products 
                  (ProductName,Image, Description, Weight,Price, Quantity, CategoryID) 
                     VALUES 
                     (@Name, @Img,@Desc,@Weight, @Price, @Qty, @Category)", con);

        cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
        cmd.Parameters.AddWithValue("@Img", fileName);
        cmd.Parameters.AddWithValue("@Desc", txtDesc.Text.Trim());
        cmd.Parameters.AddWithValue("@Weight", ddlWeight.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@Price", txtPrice.Text.Trim());
        cmd.Parameters.AddWithValue("@Qty", txtQty.Text.Trim());
        cmd.Parameters.AddWithValue("@Category", ddlCategory.SelectedValue);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        lblMsg.Text = "Product Added Successfully!";
        lblMsg.CssClass = "text-success";

        txtName.Text = "";
        txtDesc.Text = "";
        txtPrice.Text = "";
        txtQty.Text = "";
        ddlCategory.SelectedIndex = 0;
        ddlWeight.SelectedIndex = 0;
  

        //Optional alert
        Response.Write("<script>alert('Product Added Successfully!');</script>");
    }
}
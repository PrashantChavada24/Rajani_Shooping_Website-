﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

public partial class Admin_PopularProducts : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            LoadPopularProducts();
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadPopularProducts();
    }

    void LoadPopularProducts()
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
            SELECT 
                p.ProductName, p.Image,
                SUM(od.Quantity) AS SoldQty,
                SUM(od.Quantity * od.Price) AS Revenue
            FROM OrderDetails od
            INNER JOIN Products p ON od.ProductID = p.ProductID
            INNER JOIN Orders o ON od.OrderID = o.OrderID
            WHERE 1 = 1";

            if (!string.IsNullOrEmpty(txtDate.Text))
                query += " AND CONVERT(date, o.OrderDate) = @date";

            if (!string.IsNullOrEmpty(ddlMonth.SelectedValue))
                query += " AND MONTH(o.OrderDate) = @month";

            if (!string.IsNullOrEmpty(txtYear.Text))
                query += " AND YEAR(o.OrderDate) = @year";

            query += @"
            GROUP BY p.ProductName, p.Image
            ORDER BY SoldQty DESC";

            SqlCommand cmd = new SqlCommand(query, con);

            if (!string.IsNullOrEmpty(txtDate.Text))
                cmd.Parameters.AddWithValue("@date", txtDate.Text);

            if (!string.IsNullOrEmpty(ddlMonth.SelectedValue))
                cmd.Parameters.AddWithValue("@month", ddlMonth.SelectedValue);

            if (!string.IsNullOrEmpty(txtYear.Text))
                cmd.Parameters.AddWithValue("@year", txtYear.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridPopular.DataSource = dt;
            GridPopular.DataBind();

            LoadChart(dt);
        }
    }
    void LoadChart(DataTable dt)
    {
        string labels = "";
        string soldData = "";

        foreach (DataRow row in dt.Rows)
        {
            labels += "'" + row["ProductName"].ToString() + "',";
            soldData += row["SoldQty"].ToString() + ",";
        }

        string script = @"
        <script>
        var ctx = document.getElementById('salesChart');

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [" + labels + @"],
                datasets: [{
                    label: 'Units Sold',
                    data: [" + soldData + @"],
                    backgroundColor: 'rgba(255, 99, 132, 0.6)'
                }]
            }
        });
        </script>";

        ClientScript.RegisterStartupScript(this.GetType(), "chart", script);
    }

    // ============================================
    // EXPORT TO EXCEL
    // ============================================

    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=PopularProducts.xls");
        Response.ContentType = "application/vnd.ms-excel";
        Response.Charset = "";

        StringWriter sw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw);

        // Create table manually (skip image)
        sw.Write("<table border='1'><tr>");

        // HEADER (skip Image column)
        for (int i = 1; i < GridPopular.HeaderRow.Cells.Count; i++)
        {
            sw.Write("<th>" + GridPopular.HeaderRow.Cells[i].Text + "</th>");
        }

        sw.Write("</tr>");

        // ROWS (skip column 0)
        foreach (GridViewRow row in GridPopular.Rows)
        {
            sw.Write("<tr>");
            for (int i = 1; i < row.Cells.Count; i++)
            {
                sw.Write("<td>" + row.Cells[i].Text + "</td>");
            }
            sw.Write("</tr>");
        }

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }


    public override void VerifyRenderingInServerForm(Control control)
    {
    }

    // ============================================
    // EXPORT TO PDF (iTextSharp)
    // ============================================

    protected void btnExportPDF_Click(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=PopularProducts.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);

        pdfDoc.Open();

        // PDF table with 3 columns (Product, SoldQty, Revenue)
        PdfPTable table = new PdfPTable(3);
        table.WidthPercentage = 100;

        // HEADER (skip image)
        for (int i = 1; i < GridPopular.HeaderRow.Cells.Count; i++)
        {
            table.AddCell(new Phrase(GridPopular.HeaderRow.Cells[i].Text));
        }

        // ROWS (skip image)
        foreach (GridViewRow row in GridPopular.Rows)
        {
            for (int i = 1; i < row.Cells.Count; i++)
            {
                table.AddCell(new Phrase(row.Cells[i].Text));
            }
        }

        pdfDoc.Add(table);
        pdfDoc.Close();
        Response.End();
    }

}
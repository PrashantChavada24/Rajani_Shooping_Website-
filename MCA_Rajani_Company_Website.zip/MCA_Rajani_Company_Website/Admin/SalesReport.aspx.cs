﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_SalesReport : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            LoadReport();
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadReport();
    }

    void LoadReport()
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
            SELECT od.OrderID, p.ProductName, od.Quantity, od.Price,
                   (od.Quantity * od.Price) AS Total,
                   CONVERT(varchar, o.OrderDate, 23) AS OrderDate
            FROM OrderDetails od
            INNER JOIN Orders o ON od.OrderID = o.OrderID
            INNER JOIN Products p ON od.ProductID = p.ProductID
            WHERE 1=1";

            // DATE FILTER
            if (!string.IsNullOrEmpty(txtDate.Text))
                query += " AND CONVERT(date, o.OrderDate) = @date";

            // MONTH FILTER
            if (!string.IsNullOrEmpty(ddlMonth.SelectedValue))
                query += " AND MONTH(o.OrderDate) = @month";

            // YEAR FILTER
            if (!string.IsNullOrEmpty(txtYear.Text))
                query += " AND YEAR(o.OrderDate) = @year";

            // STATUS FILTER
            if (ddlStatus.SelectedValue != "All")
                query += " AND o.PaymentStatus = @status";

            SqlCommand cmd = new SqlCommand(query, con);

            if (!string.IsNullOrEmpty(txtDate.Text))
                cmd.Parameters.AddWithValue("@date", txtDate.Text);

            if (!string.IsNullOrEmpty(ddlMonth.SelectedValue))
                cmd.Parameters.AddWithValue("@month", ddlMonth.SelectedValue);

            if (!string.IsNullOrEmpty(txtYear.Text))
                cmd.Parameters.AddWithValue("@year", txtYear.Text);

            if (ddlStatus.SelectedValue != "All")
                cmd.Parameters.AddWithValue("@status", ddlStatus.SelectedValue);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridSales.DataSource = dt;
            GridSales.DataBind();

            // SUMMARY
            lblTotalOrders.Text = dt.AsEnumerable().Select(r => r["OrderID"]).Distinct().Count().ToString();
            lblTotalItems.Text = dt.AsEnumerable().Sum(r => Convert.ToInt32(r["Quantity"])).ToString();
            lblRevenue.Text = dt.AsEnumerable().Sum(r => Convert.ToDecimal(r["Total"])).ToString("0.00");

            LoadBestProduct();
        }
    }

    void LoadBestProduct()
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            string query = @"
            SELECT TOP 1 
                p.ProductName, 
                SUM(od.Quantity) AS SoldQty
            FROM OrderDetails od
            INNER JOIN Products p ON od.ProductID = p.ProductID
            INNER JOIN Orders o ON od.OrderID = o.OrderID
            WHERE 1 = 1";

            // Apply filters SAME as Sales Report
            if (!string.IsNullOrEmpty(txtDate.Text))
                query += " AND CAST(o.OrderDate AS DATE) = @date";

            if (!string.IsNullOrEmpty(ddlMonth.SelectedValue))
                query += " AND MONTH(o.OrderDate) = @month";

            if (!string.IsNullOrEmpty(txtYear.Text))
                query += " AND YEAR(o.OrderDate) = @year";

            // GROUP BY + ORDER is required
            query += " GROUP BY p.ProductName ORDER BY SoldQty DESC";

            SqlCommand cmd = new SqlCommand(query, con);

            if (!string.IsNullOrEmpty(txtDate.Text))
                cmd.Parameters.AddWithValue("@date", txtDate.Text);

            if (!string.IsNullOrEmpty(ddlMonth.SelectedValue))
                cmd.Parameters.AddWithValue("@month", ddlMonth.SelectedValue);

            if (!string.IsNullOrEmpty(txtYear.Text))
                cmd.Parameters.AddWithValue("@year", txtYear.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridBest.DataSource = dt;
            GridBest.DataBind();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_EditProduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);
    int productid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["ID"] == null)
            Response.Redirect("ManageProduct.aspx");

        productid = Convert.ToInt32(Request.QueryString["ID"]);

        if (!IsPostBack)
        {
            LoadCategory();
            LoadProduct();
        }
    
    }
    void LoadCategory()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT CategoryID, CategoryName FROM Category", con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        ddlCategory.DataSource = dt;
        ddlCategory.DataTextField = "CategoryName";
        ddlCategory.DataValueField = "CategoryID";
        ddlCategory.DataBind();
    }
    void LoadProduct()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT * FROM Products WHERE ProductID=@ID", con);
        cmd.Parameters.AddWithValue("@ID", productid);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txtName.Text = dr["ProductName"].ToString();
            txtDesc.Text = dr["Description"].ToString();
            ddlWeight.SelectedValue = dr["Weight"].ToString();
            txtPrice.Text = dr["Price"].ToString();
            txtQty.Text = dr["Quantity"].ToString();
            
            ddlCategory.SelectedValue = dr["CategoryID"].ToString();

            imgOld.ImageUrl = "~/ProductImages/" + dr["Image"].ToString();
            ViewState["OldImage"] = dr["Image"].ToString();
        }
        con.Close();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string img = ViewState["OldImage"].ToString();

        // If new image uploaded
        if (FileImage.HasFile)
        {
            string ext = System.IO.Path.GetExtension(FileImage.FileName).ToLower();

            if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
            {
                lblMsg.Text = "Only JPG/PNG allowed!";
                lblMsg.CssClass = "text-danger";
                return;
            }

            img = Guid.NewGuid().ToString() + ext;
            FileImage.SaveAs(Server.MapPath("~/ProductImages/" + img));
        }

        con.Open();
        SqlCommand cmd = new SqlCommand(
            @"UPDATE Products SET 
                ProductName=@Name, 
                Description=@Desc,
                Weight=@Weight,
                Price=@Price,
                Quantity=@Qty,
                CategoryID=@CatID,
                Image=@Img
              WHERE ProductID=@ID", con);

        cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
        cmd.Parameters.AddWithValue("@Desc", txtDesc.Text.Trim());
        cmd.Parameters.AddWithValue("@Weight", ddlWeight.SelectedValue);
        cmd.Parameters.AddWithValue("@Price", txtPrice.Text.Trim());
        cmd.Parameters.AddWithValue("@Qty", txtQty.Text.Trim());
        cmd.Parameters.AddWithValue("@CatID", ddlCategory.SelectedValue);
        cmd.Parameters.AddWithValue("@Img", img);
        cmd.Parameters.AddWithValue("@ID", productid);

        cmd.ExecuteNonQuery();
        con.Close();

        // Clear fields
        txtName.Text = "";
        txtDesc.Text = "";
        txtPrice.Text = "";
        txtQty.Text = "";
        ddlCategory.SelectedIndex = 0;
        imgOld.ImageUrl = "";

        Response.Write("<script>alert('Product Update Successfully!');</script>");
        Response.Redirect("ManageProduct.aspx");
    }

}
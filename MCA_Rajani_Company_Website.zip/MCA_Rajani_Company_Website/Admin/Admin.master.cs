﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string page = System.IO.Path.GetFileName(Request.Url.AbsolutePath);

        // Highlight current menu
        if (page == "AddCategory.aspx") lnkCategory.Attributes["class"] = "active";
        if (page == "AdminHome.aspx") lnkDashboard.Attributes["class"] = "active";
        if (page == "AddProduct.aspx") lnkAddProduct.Attributes["class"] = "active";
        if (page == "ManageProduct.aspx") lnkManageProduct.Attributes["class"] = "active";
        if (page == "Orders.aspx") lnkOrders.Attributes["class"] = "active";
        if (page == "SalesReport.aspx") lnkSales.Attributes["class"] = "active";
        if (page == "PopularProducts.aspx") lnkPopular.Attributes["class"] = "active";
        if (page == "UserList.aspx") lnkCustomers.Attributes["class"] = "active";


        if (page == "~/Login/Login.aspx") lnkLogout.Attributes["class"] = "active";
    }
}

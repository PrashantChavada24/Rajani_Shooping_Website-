﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_UserListaspx : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadUsers();
        }
    }
    void LoadUsers()
    {
        SqlDataAdapter da = new SqlDataAdapter(
            "SELECT UserID, FullName, Username, Email, Address,Gender, Mobile  FROM Users",
            con);

        DataTable dt = new DataTable();
        da.Fill(dt);

        GridUsers.DataSource = dt;
        GridUsers.DataBind();
    }
}
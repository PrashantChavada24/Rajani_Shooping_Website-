﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_AdminHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadDashboardCounts();
            LoadRecentOrders();
        }
    }
    void LoadDashboardCounts()
    {
        con.Open();

        SqlCommand cmd1 = new SqlCommand("SELECT COUNT(*) FROM Products", con);
        lblProducts.Text = cmd1.ExecuteScalar().ToString();

        SqlCommand cmd2 = new SqlCommand("SELECT COUNT(*) FROM Orders", con);
        lblOrders.Text = cmd2.ExecuteScalar().ToString();

        SqlCommand cmd3 = new SqlCommand("SELECT COUNT(*) FROM Users", con);
        lblCustomers.Text = cmd3.ExecuteScalar().ToString();

        con.Close();
    }
    void LoadRecentOrders()
    {
        con.Open();

        SqlDataAdapter da = new SqlDataAdapter(
            @"SELECT TOP 5 
              O.OrderID,
              U.FullName,
              O.OrderTotal,
              O.OrderDate
          FROM Orders O
          INNER JOIN Users U ON O.UserID = U.UserID
          ORDER BY O.OrderID DESC", con);

        DataTable dt = new DataTable();
        da.Fill(dt);

        GridRecentOrders.DataSource = dt;
        GridRecentOrders.DataBind();

        con.Close();
    }
}
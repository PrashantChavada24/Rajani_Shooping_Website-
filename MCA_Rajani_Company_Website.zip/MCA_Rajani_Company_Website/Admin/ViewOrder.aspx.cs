﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_ViewOrder : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);
    int orderid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["ID"] == null)
            Response.Redirect("Orders.aspx");

        orderid = Convert.ToInt32(Request.QueryString["ID"]);

        if (!IsPostBack)
        {
            LoadOrderDetails();
            LoadOrderItems();
        }
    }

    // LOAD ORDER MAIN DETAILS + CUSTOMER DETAILS
    void LoadOrderDetails()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand(@"
            SELECT O.OrderID, O.InvoiceNo, O.OrderDate, O.PaymentMethod, 
                   O.PaymentStatus, O.OrderStatus, O.OrderTotal,
                   U.FullName, U.Email, U.Mobile, U.Address
            FROM Orders O
            INNER JOIN Users U ON O.UserID = U.UserID
            WHERE O.OrderID = @ID", con);

        cmd.Parameters.AddWithValue("@ID", orderid);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            // Order
            lblOrderID.Text = "Order ID: " + dr["OrderID"].ToString();
            lblInvoice.Text = "Invoice No: " + dr["InvoiceNo"].ToString();
            lblOrderDate.Text = "Order Date: " + Convert.ToDateTime(dr["OrderDate"]).ToString("dd-MM-yyyy");
            lblPaymentMethod.Text = "Payment Method: " + dr["PaymentMethod"].ToString();
            lblPaymentStatus.Text = "Payment Status: " + dr["PaymentStatus"].ToString();
            lblOrderStatus.Text = "Order Status: " + dr["OrderStatus"].ToString();

            // Customer
            lblCustName.Text = "Name: " + dr["FullName"].ToString();
            lblCustEmail.Text = "Email: " + dr["Email"].ToString();
            lblCustMobile.Text = "Mobile: " + dr["Mobile"].ToString();
            lblCustAddress.Text = "Address: " + dr["Address"].ToString();

            // Grand Total
            lblGrandTotal.Text = "Grand Total: ₹" + dr["OrderTotal"].ToString();
        }

        con.Close();
    }

    // LOAD ORDER ITEMS
    void LoadOrderItems()
    {
        SqlDataAdapter da = new SqlDataAdapter(@"
            SELECT P.ProductName, I.Weight, I.Price, I.Quantity,
                   (I.Price * I.Quantity) AS Total
            FROM OrderDetails I
            INNER JOIN Products P ON I.ProductID = P.ProductID
            WHERE I.OrderID = @ID", con);

        da.SelectCommand.Parameters.AddWithValue("@ID", orderid);

        DataTable dt = new DataTable();
        da.Fill(dt);

        GridItems.DataSource = dt;
        GridItems.DataBind();
    }
}
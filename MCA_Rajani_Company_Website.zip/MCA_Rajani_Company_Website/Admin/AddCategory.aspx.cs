﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_Categories : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCategory();
        }
    }
    void LoadCategory()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT CategoryID,CategoryName FROM Category ORDER BY CategoryID ASC", con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        GridCategory.DataSource = dt;
        GridCategory.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (txtCategory.Text == "")
        {
            lblMsg.Text = "Please enter category name!";
            lblMsg.CssClass = "text-danger fw-bold";
            return;
        }

        con.Open();
        SqlCommand cmd = new SqlCommand("INSERT INTO Category (CategoryName) VALUES (@CategoryName)", con);
        cmd.Parameters.AddWithValue("@CategoryName", txtCategory.Text);
        cmd.ExecuteNonQuery();
        con.Close();

        lblMsg.Text = "Category Added Successfully!";
        lblMsg.CssClass = "text-success fw-bold";

        txtCategory.Text = "";

        LoadCategory();
    }

    // Edit Mode
    protected void GridCategory_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
    {
        GridCategory.EditIndex = e.NewEditIndex;
        LoadCategory();
    }

    // Update Category
    protected void GridCategory_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
    {
        int id = Convert.ToInt32(GridCategory.DataKeys[e.RowIndex].Value);

        TextBox txtName = (TextBox)GridCategory.Rows[e.RowIndex].Cells[1].Controls[0];

        con.Open();
        SqlCommand cmd = new SqlCommand("UPDATE Category SET CategoryName=@CategoryName WHERE CategoryID=@CatID", con);
        cmd.Parameters.AddWithValue("@CategoryName", txtName.Text);
        cmd.Parameters.AddWithValue("@CatID", id);
        cmd.ExecuteNonQuery();
        con.Close();

        GridCategory.EditIndex = -1;
        LoadCategory();
    }

    // Cancel Edit
    protected void GridCategory_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
    {
        GridCategory.EditIndex = -1;
        LoadCategory();
    }

    // Delete Category
    protected void GridCategory_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
    {
        int id = Convert.ToInt32(GridCategory.DataKeys[e.RowIndex].Value);

        con.Open();
        SqlCommand cmd = new SqlCommand("DELETE FROM Category WHERE CategoryID=@CatID", con);
        cmd.Parameters.AddWithValue("@CatID", id);
        cmd.ExecuteNonQuery();
        con.Close();

        LoadCategory();
    }
}